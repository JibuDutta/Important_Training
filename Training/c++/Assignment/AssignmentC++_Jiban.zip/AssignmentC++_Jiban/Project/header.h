#include<iostream>
#include<cstring>
//#include"Student.h"
#include"Course.h"
#include"Teacher.h"
using namespace std;
